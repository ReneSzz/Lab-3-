﻿' Made by: Rene Suarez 
' Date: June 30th 2020
' Program desciption: Stores the amount of units per day and calculates the average of units over 7 days for 3 employees. 
' Once the totals For all three employees has been entered the total average Is shown 
' The user has a enter button, a reset button, and a Exit button.       


Option Strict On
Public Class frmLab1

#Region "Event Handlers"

    ' When the form loads the text boxes and labels get filled

    Private Sub frmLab1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        textboxArray = {txtUnitsEmployee1, txtUnitsEmployee2, txtUnitsEmployee3}
        outputLabelArray = {lblEmployee1Average, lblEmployee2Average, lblEmployee3Average}
    End Sub

#End Region
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtInput.TextChanged

    End Sub

    ' Declaring Variables

    Dim enteredUnits As Integer = 0
    Dim employeeNumber As Integer = 0
    Dim employeesTotalUnits As Double
    Dim totalUnits As Double
    Dim employeesAverageUnits As Double
    Dim totalAverageUnits As Double
    Dim unitsArray(2, 6) As Double
    Dim textboxArray() As TextBox
    Dim outputLabelArray() As Label
    Dim DaysInWeek As Integer = 7
    Dim numberOfEmployees As Integer = 3



    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click



        ' Input validation checking to see if the input is a double between 0 and 5000  

        If Double.TryParse(txtInput.Text, unitsArray(employeeNumber, enteredUnits)) And unitsArray(employeeNumber, enteredUnits) > 0 And unitsArray(employeeNumber, enteredUnits) < 5000 Then

            'If the input is valid then the following code is ran

            ' fills the textbox and the array 
            textboxArray(employeeNumber).Text &= unitsArray(employeeNumber, enteredUnits) & vbCrLf
            ' increases day counter
            enteredUnits += 1
            lblDay.Text = "Day " & (enteredUnits + 1)

            ' clears txtInput box
            txtInput.Clear()
            ' refocuses back to the txtInput box so user can quickly enter the next unit 
            txtInput.Focus()

            If enteredUnits = DaysInWeek Then

                ' Reset the employees total
                employeesTotalUnits = 0

                ' gathering a total units for the employees
                For dayCounter As Integer = 0 To DaysInWeek - 1
                    employeesTotalUnits += unitsArray(employeeNumber, dayCounter)
                Next

                ' determine and then outputs the average units for the employee
                employeesAverageUnits = employeesTotalUnits / DaysInWeek
                outputLabelArray(employeeNumber).Text = "Average: " & Math.Round(employeesAverageUnits, 2)

                ' Increment the employeeNumber
                employeeNumber += 1
                ' Reset the day counter to 0
                enteredUnits = 0
                lblDay.Text = "Day " & (enteredUnits + 1)

                ' Once the employeeNumber is equal to numberOfEmployees then the following code gets executed
                If employeeNumber = numberOfEmployees Then

                    ' Gathers the total units from all the employees
                    For Each day In unitsArray
                        totalUnits += day
                    Next

                    ' creates then outputs the total average amount from all employees
                    totalAverageUnits = totalUnits / unitsArray.Length
                    lblAverageUnitsTotal.Text = "Company's total average : " & Math.Round(totalAverageUnits, 2)

                    ' Disable the controls that are no longer needed and re-focuses onto the reset button
                    txtInput.Enabled = False
                    btnEnter.Enabled = False
                    btnReset.Focus()



                End If

            End If

            ' If the entry is not a number greater than 0 and less than 5000 this error message pops up 
        Else
            MessageBox.Show(" Input must be a number greater than 0 and less than 5000.")
            txtInput.SelectAll()
            txtInput.Focus()
        End If


    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' Clears the text boxes 
        txtInput.Clear()
        txtUnitsEmployee1.Clear()
        txtUnitsEmployee2.Clear()
        txtUnitsEmployee3.Clear()
        ' Clears employee averages labels
        lblEmployee1Average.Text = String.Empty
        lblEmployee2Average.Text = String.Empty
        lblEmployee3Average.Text = String.Empty
        lblAverageUnitsTotal.Text = String.Empty
        ' Re-enables input text box and the enter button
        txtInput.Enabled = True
        btnEnter.Enabled = True
        ' resets the values to 0 
        enteredUnits = 0
        employeeNumber = 0
        lblDay.Text = "Day " & (enteredUnits + 1)
        employeesTotalUnits = 0
        totalUnits = 0
        txtInput.Focus()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        ' Closes the program
        Close()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblTotalUnits_Click(sender As Object, e As EventArgs) Handles lblEmployee1Average.Click




    End Sub

    Private Sub lblAverage_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblAverageText_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblDay_Click(sender As Object, e As EventArgs) Handles lblDay.Click

    End Sub
End Class
