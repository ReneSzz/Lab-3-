﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLab1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.txtUnitsEmployee1 = New System.Windows.Forms.TextBox()
        Me.lblDay = New System.Windows.Forms.Label()
        Me.lblEmployee1Average = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.txtUnitsEmployee2 = New System.Windows.Forms.TextBox()
        Me.txtUnitsEmployee3 = New System.Windows.Forms.TextBox()
        Me.lblEmployee2Average = New System.Windows.Forms.Label()
        Me.lblEmployee3Average = New System.Windows.Forms.Label()
        Me.lblAverageUnitsTotal = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(12, 314)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 1
        Me.btnEnter.Text = "&Enter"
        Me.ToolTip1.SetToolTip(Me.btnEnter, "Click or press enter to input data to the form.")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(124, 314)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 2
        Me.btnReset.Text = "&Reset"
        Me.ToolTip1.SetToolTip(Me.btnReset, " Click this to reset the form.")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(235, 314)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "E&xit"
        Me.ToolTip1.SetToolTip(Me.btnExit, "Click this to exit the form.")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblUnits
        '
        Me.lblUnits.AutoSize = True
        Me.lblUnits.Location = New System.Drawing.Point(30, 48)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(90, 13)
        Me.lblUnits.TabIndex = 4
        Me.lblUnits.Text = "Number of units : "
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(126, 48)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(119, 20)
        Me.txtInput.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtInput, " Enter the unit numbers for the day here")
        '
        'txtUnitsEmployee1
        '
        Me.txtUnitsEmployee1.Location = New System.Drawing.Point(19, 106)
        Me.txtUnitsEmployee1.Multiline = True
        Me.txtUnitsEmployee1.Name = "txtUnitsEmployee1"
        Me.txtUnitsEmployee1.ReadOnly = True
        Me.txtUnitsEmployee1.Size = New System.Drawing.Size(119, 141)
        Me.txtUnitsEmployee1.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.txtUnitsEmployee1, "Units per day tracker")
        '
        'lblDay
        '
        Me.lblDay.AutoSize = True
        Me.lblDay.Location = New System.Drawing.Point(49, 19)
        Me.lblDay.Name = "lblDay"
        Me.lblDay.Size = New System.Drawing.Size(38, 13)
        Me.lblDay.TabIndex = 5
        Me.lblDay.Text = "Day 1 "
        '
        'lblEmployee1Average
        '
        Me.lblEmployee1Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee1Average.Location = New System.Drawing.Point(19, 250)
        Me.lblEmployee1Average.Name = "lblEmployee1Average"
        Me.lblEmployee1Average.Size = New System.Drawing.Size(119, 17)
        Me.lblEmployee1Average.TabIndex = 7
        Me.lblEmployee1Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblEmployee1Average, "Average of total units")
        '
        'txtUnitsEmployee2
        '
        Me.txtUnitsEmployee2.Location = New System.Drawing.Point(155, 106)
        Me.txtUnitsEmployee2.Multiline = True
        Me.txtUnitsEmployee2.Name = "txtUnitsEmployee2"
        Me.txtUnitsEmployee2.ReadOnly = True
        Me.txtUnitsEmployee2.Size = New System.Drawing.Size(119, 141)
        Me.txtUnitsEmployee2.TabIndex = 9
        Me.ToolTip1.SetToolTip(Me.txtUnitsEmployee2, "Units per day tracker")
        '
        'txtUnitsEmployee3
        '
        Me.txtUnitsEmployee3.Location = New System.Drawing.Point(289, 106)
        Me.txtUnitsEmployee3.Multiline = True
        Me.txtUnitsEmployee3.Name = "txtUnitsEmployee3"
        Me.txtUnitsEmployee3.ReadOnly = True
        Me.txtUnitsEmployee3.Size = New System.Drawing.Size(119, 141)
        Me.txtUnitsEmployee3.TabIndex = 10
        Me.ToolTip1.SetToolTip(Me.txtUnitsEmployee3, "Units per day tracker")
        '
        'lblEmployee2Average
        '
        Me.lblEmployee2Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee2Average.Location = New System.Drawing.Point(155, 250)
        Me.lblEmployee2Average.Name = "lblEmployee2Average"
        Me.lblEmployee2Average.Size = New System.Drawing.Size(119, 17)
        Me.lblEmployee2Average.TabIndex = 11
        Me.lblEmployee2Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblEmployee2Average, "Average of total units")
        '
        'lblEmployee3Average
        '
        Me.lblEmployee3Average.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblEmployee3Average.Location = New System.Drawing.Point(289, 250)
        Me.lblEmployee3Average.Name = "lblEmployee3Average"
        Me.lblEmployee3Average.Size = New System.Drawing.Size(119, 17)
        Me.lblEmployee3Average.TabIndex = 12
        Me.lblEmployee3Average.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblEmployee3Average, "Average of total units")
        '
        'lblAverageUnitsTotal
        '
        Me.lblAverageUnitsTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAverageUnitsTotal.Location = New System.Drawing.Point(103, 278)
        Me.lblAverageUnitsTotal.Name = "lblAverageUnitsTotal"
        Me.lblAverageUnitsTotal.Size = New System.Drawing.Size(202, 17)
        Me.lblAverageUnitsTotal.TabIndex = 13
        Me.lblAverageUnitsTotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblAverageUnitsTotal, "Average of total units")
        '
        'frmLab1
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(427, 393)
        Me.Controls.Add(Me.lblAverageUnitsTotal)
        Me.Controls.Add(Me.lblEmployee3Average)
        Me.Controls.Add(Me.lblEmployee2Average)
        Me.Controls.Add(Me.txtUnitsEmployee3)
        Me.Controls.Add(Me.txtUnitsEmployee2)
        Me.Controls.Add(Me.lblEmployee1Average)
        Me.Controls.Add(Me.lblDay)
        Me.Controls.Add(Me.txtUnitsEmployee1)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.lblUnits)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLab1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Per Day Calculator 2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblUnits As Label
    Friend WithEvents txtInput As TextBox
    Friend WithEvents txtUnitsEmployee1 As TextBox
    Friend WithEvents lblDay As Label
    Friend WithEvents lblEmployee1Average As Label
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents txtUnitsEmployee2 As TextBox
    Friend WithEvents txtUnitsEmployee3 As TextBox
    Friend WithEvents lblEmployee2Average As Label
    Friend WithEvents lblEmployee3Average As Label
    Friend WithEvents lblAverageUnitsTotal As Label
End Class
