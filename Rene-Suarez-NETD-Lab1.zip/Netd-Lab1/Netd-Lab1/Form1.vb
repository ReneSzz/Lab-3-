﻿' Made by: Rene Suarez 
' Date: May 30th 2020
' Program desciption: Stores the amount of units per day and calculates the average of units over 7 days. 
' The user has a enter button, a reset button, and a Exit button.       


Option Strict On
Public Class frmLab1
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtInput.TextChanged

    End Sub




    ' Declaring Variables
    Dim dayCounter As Integer = 1
    Dim unitsTotal As Double = 0
    Dim enteredDay As Integer = 0


    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click




        ' Increases dayCounter by 1 each time the button is clicked 
        dayCounter = dayCounter + 1



        ' Input validation checking to see if the input is a number between 0 and 5000  

        If Integer.TryParse(txtInput.Text, enteredDay) And enteredDay > 0 And enteredDay < 5000 Then

            'If the input is valid then the following code is ran


            ' unitsTotal has the entered units for the day added to it
            unitsTotal += enteredDay
            ' Updates day counter with each succesful input
            lblDayCount.Text = "Day " & dayCounter
            ' has the input placed into the box on a seperate line
            txtDays.Text &= enteredDay & vbCrLf
            ' clears txtInput box
            txtInput.Clear()
            ' refocuses back to the txtInput box so user can quickly enter the next unit 
            txtInput.Focus()




            ' Error message if the input is not valid 
        Else
            MessageBox.Show("The entered number must be a whole number between 0 and 5000.")
            ' refocuses onto the txtInput box for the user to make a new input.
            txtInput.Focus()






        End If



        'If dayCounter is 8 then  the following code gets executed 
        If dayCounter = 8 Then
            ' Set the day count box back to 7 just for simplicity
            lblDayCount.Text = "Day 7"
            'txtInput becomes read only so the user cant input anymore data until the form is reset
            txtInput.ReadOnly = True
            'the enter button is disabled
            btnEnter.Enabled = False
            'the calculated average in the label is shown
            lblAverageText.Show()





            'the program then divides the total units by 7 to get the average
            unitsTotal = unitsTotal / 7
            ' converts unitsTotal to a string to be displayed in label
            lblTotalUnits.Text = unitsTotal.ToString()


        End If


    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        ' Clears average label 
        lblTotalUnits.Text = ("")
        ' clears txtInput box
        txtInput.Clear()
        ' clears txtDays 
        txtDays.Clear()
        ' reenables txtInput box so user can enter units again
        txtInput.ReadOnly = False
        'brings back the enter buttton
        btnEnter.Enabled = True

        'resets dayCounter value 
        dayCounter = 1
        'Reset unitsTotal 
        unitsTotal = 0
        ' Changes day count back to 1 
        lblDayCount.Text = "Day " & dayCounter
        ' Refocuses onto txtInput
        txtInput.Focus()





    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        ' Closes the program
        Close()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblTotalUnits_Click(sender As Object, e As EventArgs) Handles lblTotalUnits.Click




    End Sub

    Private Sub lblAverage_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub lblAverageText_Click(sender As Object, e As EventArgs) Handles lblAverageText.Click

    End Sub
End Class
