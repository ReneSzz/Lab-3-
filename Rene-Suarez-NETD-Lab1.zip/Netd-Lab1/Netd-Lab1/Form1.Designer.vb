﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLab1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblUnits = New System.Windows.Forms.Label()
        Me.txtInput = New System.Windows.Forms.TextBox()
        Me.txtDays = New System.Windows.Forms.TextBox()
        Me.lblDayCount = New System.Windows.Forms.Label()
        Me.lblTotalUnits = New System.Windows.Forms.Label()
        Me.lblAverageText = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(12, 314)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 1
        Me.btnEnter.Text = "&Enter"
        Me.ToolTip1.SetToolTip(Me.btnEnter, "Click or press enter to input data to the form.")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(124, 314)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 2
        Me.btnReset.Text = "&Reset"
        Me.ToolTip1.SetToolTip(Me.btnReset, " Click this to reset the form.")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(235, 314)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "E&xit"
        Me.ToolTip1.SetToolTip(Me.btnExit, "Click this to exit the form.")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblUnits
        '
        Me.lblUnits.AutoSize = True
        Me.lblUnits.Location = New System.Drawing.Point(12, 67)
        Me.lblUnits.Name = "lblUnits"
        Me.lblUnits.Size = New System.Drawing.Size(90, 13)
        Me.lblUnits.TabIndex = 4
        Me.lblUnits.Text = "Number of units : "
        '
        'txtInput
        '
        Me.txtInput.Location = New System.Drawing.Point(103, 64)
        Me.txtInput.Name = "txtInput"
        Me.txtInput.Size = New System.Drawing.Size(119, 20)
        Me.txtInput.TabIndex = 0
        Me.ToolTip1.SetToolTip(Me.txtInput, " Enter the unit numbers for the day here")
        '
        'txtDays
        '
        Me.txtDays.Location = New System.Drawing.Point(103, 105)
        Me.txtDays.Multiline = True
        Me.txtDays.Name = "txtDays"
        Me.txtDays.ReadOnly = True
        Me.txtDays.Size = New System.Drawing.Size(119, 141)
        Me.txtDays.TabIndex = 8
        Me.ToolTip1.SetToolTip(Me.txtDays, "Units per day tracker")
        '
        'lblDayCount
        '
        Me.lblDayCount.AutoSize = True
        Me.lblDayCount.Location = New System.Drawing.Point(232, 64)
        Me.lblDayCount.Name = "lblDayCount"
        Me.lblDayCount.Size = New System.Drawing.Size(38, 13)
        Me.lblDayCount.TabIndex = 5
        Me.lblDayCount.Text = "Day 1 "
        '
        'lblTotalUnits
        '
        Me.lblTotalUnits.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalUnits.Location = New System.Drawing.Point(155, 276)
        Me.lblTotalUnits.Name = "lblTotalUnits"
        Me.lblTotalUnits.Size = New System.Drawing.Size(67, 14)
        Me.lblTotalUnits.TabIndex = 7
        Me.lblTotalUnits.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTip1.SetToolTip(Me.lblTotalUnits, "Average of total units")
        '
        'lblAverageText
        '
        Me.lblAverageText.AutoSize = True
        Me.lblAverageText.Location = New System.Drawing.Point(12, 276)
        Me.lblAverageText.Name = "lblAverageText"
        Me.lblAverageText.Size = New System.Drawing.Size(126, 13)
        Me.lblAverageText.TabIndex = 6
        Me.lblAverageText.Text = "The Average Per Day is: "
        Me.lblAverageText.Visible = False
        '
        'frmLab1
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(318, 393)
        Me.Controls.Add(Me.lblAverageText)
        Me.Controls.Add(Me.lblTotalUnits)
        Me.Controls.Add(Me.lblDayCount)
        Me.Controls.Add(Me.txtDays)
        Me.Controls.Add(Me.txtInput)
        Me.Controls.Add(Me.lblUnits)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLab1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Average Units Per Day Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblUnits As Label
    Friend WithEvents txtInput As TextBox
    Friend WithEvents txtDays As TextBox
    Friend WithEvents lblDayCount As Label
    Friend WithEvents lblTotalUnits As Label
    Friend WithEvents lblAverageText As Label
    Friend WithEvents ToolTip1 As ToolTip
End Class
